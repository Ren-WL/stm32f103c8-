
#ifndef __RCC_H
#define	__RCC_H

 

void 	RCC_Config(void);



#endif 
