#ifndef __LED_H
#define	__LED_H

#include "stm32f10x.h"

 
/*  LEDʱ�Ӷ˿ڡ����Ŷ��� */
#define LED_PORT 			GPIOB   
#define LED_PIN 			 ( GPIO_Pin_15|GPIO_Pin_11)
#define LED_PORT_RCC		RCC_APB2Periph_GPIOB


#define led PBout(14)

void LED_GPIO_Config(void);

#endif  


