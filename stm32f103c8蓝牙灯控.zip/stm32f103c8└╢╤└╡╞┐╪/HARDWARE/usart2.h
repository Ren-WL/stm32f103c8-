

#ifndef __USART2_H
#define	__USART2_H

 

void USART2_Config(void);
void USART2_IRQHandler(void);	


#endif 





