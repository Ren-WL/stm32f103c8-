


#include "misc.h"
#include "nvic.h"

 

void NVIC_Config(void)
	{	
		 NVIC_InitTypeDef NVIC_InitStructure;
		 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
		 NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
     NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;//��ռ���ȼ�3
     NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;        //�����ȼ�3
     NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;            //IRQͨ��ʹ��
     NVIC_Init(&NVIC_InitStructure);  
	} 
	
	