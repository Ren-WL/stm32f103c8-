#include "stm32f10x_usart.h"
#include "misc.h"

	
void USART2_Config(void)//usart2 ʹ��
	{
		
		USART_InitTypeDef USART_InitStructure;  
    USART_InitStructure.USART_BaudRate = 9600;  
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;  
    USART_InitStructure.USART_StopBits = USART_StopBits_1;  
    USART_InitStructure.USART_Parity = USART_Parity_No;  
		
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;  
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;  
    USART_Init(USART2, &USART_InitStructure); 
	  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);//���������ж�
//		USART_ITConfig(USART2, USART_IT_TXE, ENABLE); //���������ж�	
	  USART_Cmd(USART2, ENABLE);
		
}
