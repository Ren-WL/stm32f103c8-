

 

#include "misc.h"
#include "stm32f10x_usart.h"
#include "usart2.h"
#include "gpio.h"
#include "rcc.h"
#include "led.h"
#include "bmp.h" 
 
void Delay(uint32_t nCount)
{
  for(; nCount != 0; nCount--);
}

 void NVIC_Config(void)
	{	
		 NVIC_InitTypeDef NVIC_InitStructure;
		 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
		 NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
     NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;//��ռ���ȼ�3
     NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;        //�����ȼ�3
     NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;            //IRQͨ��ʹ��
     NVIC_Init(&NVIC_InitStructure);  
	}
 u8 x,flag=0;
   void USART2_IRQHandler(void)       
     {		 
	      if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)//���������ж�
			  {				
				  x=USART_ReceiveData(USART2);
					USART_SendData(USART2,x);
					USART_SendData(USART2,0x99);
					flag=!flag;
					while(1)
					{
						LED1(flag);
						break;
					}
					while (USART_GetFlagStatus(USART2, USART_FLAG_TC) == SET); //����ж�
			  }USART_ClearFlag(USART1,USART_FLAG_TC);
	 }

int main(void)
{
	//����ͨ��
	LED_GPIO_Config();
	RCC_Config();   														//ʱ������
	GPIO_Config();															//usart1  usart2 ����
	NVIC_Config();	
	USART2_Config();     												//LORA
  while (1)
  { 
  }
}


 
 
 


